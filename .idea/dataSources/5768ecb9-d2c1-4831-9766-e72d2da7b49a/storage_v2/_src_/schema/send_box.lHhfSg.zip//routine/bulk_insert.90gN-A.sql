create
    definer = root@localhost procedure bulk_insert()
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < 10000000 DO
        INSERT INTO orders_sample(user_id, product_id, status, amount, created_at, updated_at, region, category, note)
        VALUES (
            FLOOR(RAND() * 1000000),
            FLOOR(RAND() * 1000000),
            ELT(FLOOR(RAND()*4)+1,'PAID','CANCEL','REFUND','COMPLETED'),
            ROUND(RAND()*100000, 2),
            NOW() - INTERVAL FLOOR(RAND()*365) DAY,
            NOW(),
            ELT(FLOOR(RAND()*5)+1,'Seoul','Busan','Daegu','Daejeon','Jeju'),
            ELT(FLOOR(RAND()*5)+1,'ELECTRONICS','CLOTHES','BOOK','FOOD','SPORT'),
            UUID()
        );
        SET i = i + 1;
    END WHILE;
END;

