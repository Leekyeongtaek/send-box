create
    definer = root@localhost procedure insert_hierarchy_1000()
BEGIN
  DECLARE i INT DEFAULT 1;
  DECLARE j INT;
  DECLARE k INT;
  DECLARE level2_start BIGINT;
  DECLARE level3_start BIGINT;

  -- 1️⃣ 루트가 직접 10명 추천 (1차 하위)
  SET i = 1;
  WHILE i <= 10 DO
    INSERT INTO user_referrer (user_master_id, referrer_user_master_id, has_child)
    VALUES (6001 + i, 6001, 'Y');
    SET i = i + 1;
  END WHILE;

  -- 2️⃣ 각 1차 하위가 10명씩 추천 (2차 하위)
  SET i = 1;
  SET level2_start = 6002;
  SET level3_start = 6012;  -- 2차 하위 시작 ID
  WHILE i <= 10 DO
    SET j = 1;
    WHILE j <= 10 DO
      INSERT INTO user_referrer (user_master_id, referrer_user_master_id, has_child)
      VALUES (level3_start, level2_start + (i - 1), 'Y');
      SET level3_start = level3_start + 1;
      SET j = j + 1;
    END WHILE;
    SET i = i + 1;
  END WHILE;

  -- 3️⃣ 각 2차 하위가 8명씩 추천 (3차 하위)
  SET i = 6012;  -- 2차 시작 ID
  SET k = 1;
  WHILE i < 6112 DO
    SET j = 1;
    WHILE j <= 8 DO
      INSERT INTO user_referrer (user_master_id, referrer_user_master_id, has_child)
      VALUES (6112 + (k - 1), i, NULL);
      SET k = k + 1;
      SET j = j + 1;
    END WHILE;
    SET i = i + 1;
  END WHILE;

END;

